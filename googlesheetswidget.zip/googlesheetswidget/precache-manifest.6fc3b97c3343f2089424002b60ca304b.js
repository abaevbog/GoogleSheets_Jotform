self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a30f70f1e481cc3bcef5f114cecbabf1",
    "url": "/googlesheetswidget/index.html"
  },
  {
    "revision": "b8d3c4eede2c273ac071",
    "url": "/googlesheetswidget/static/css/2.177b91ab.chunk.css"
  },
  {
    "revision": "5403a46971d85b33d963",
    "url": "/googlesheetswidget/static/css/main.b1f82f48.chunk.css"
  },
  {
    "revision": "b8d3c4eede2c273ac071",
    "url": "/googlesheetswidget/static/js/2.58b20a58.chunk.js"
  },
  {
    "revision": "5403a46971d85b33d963",
    "url": "/googlesheetswidget/static/js/main.46a0e4f8.chunk.js"
  },
  {
    "revision": "7eab2af5ca2f57617d3b",
    "url": "/googlesheetswidget/static/js/runtime~main.b498a1b1.js"
  }
]);