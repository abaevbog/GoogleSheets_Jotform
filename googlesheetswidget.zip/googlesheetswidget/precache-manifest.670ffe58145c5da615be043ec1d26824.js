self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f7fc77cbcecaf5917310fabf7c70aa63",
    "url": "/googlesheetswidget/index.html"
  },
  {
    "revision": "350a57b27374cc8bb3d3",
    "url": "/googlesheetswidget/static/css/2.177b91ab.chunk.css"
  },
  {
    "revision": "7068b9fc1b4dc8c27d27",
    "url": "/googlesheetswidget/static/css/main.f65aa1a5.chunk.css"
  },
  {
    "revision": "350a57b27374cc8bb3d3",
    "url": "/googlesheetswidget/static/js/2.f857f83d.chunk.js"
  },
  {
    "revision": "7068b9fc1b4dc8c27d27",
    "url": "/googlesheetswidget/static/js/main.2577dda5.chunk.js"
  },
  {
    "revision": "7eab2af5ca2f57617d3b",
    "url": "/googlesheetswidget/static/js/runtime~main.b498a1b1.js"
  }
]);